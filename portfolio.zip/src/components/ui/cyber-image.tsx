import { CyberFrame } from './cyber-frame'
import { cyberFrameClip } from './cyber-frame-path'

import { cn } from '@/lib/utils'

export type CyberImageProps = {
  src: string
  alt: string
  width?: number
  height?: number
  loading?: 'eager' | 'lazy'
  decoding?: 'async' | 'sync' | 'auto'
  fetchPriority?: 'high' | 'low' | 'auto'
  srcSet?: string
  sizes?: string
  frameClassName?: string
  contentClassName?: string
  imgClassName?: string
  stroke?: string | false
  strokeWidth?: number
  fill?: string
  chamferX?: number
  chamferY?: number
  imgRef?: React.Ref<HTMLImageElement>
}

export function CyberImage({
  src,
  alt,
  width,
  height,
  loading = 'eager',
  decoding = 'async',
  fetchPriority = 'auto',
  srcSet,
  sizes,
  frameClassName,
  contentClassName,
  imgClassName,
  stroke,
  strokeWidth,
  fill,
  chamferX = 54,
  chamferY = 54,
  imgRef,
}: CyberImageProps) {
  return (
    <CyberFrame
      data-slot="cyber-image"
      className={cn('w-full', frameClassName)}
      contentClassName={cn('p-0', contentClassName)}
      stroke={stroke}
      strokeWidth={strokeWidth}
      fill={fill}
      chamferX={chamferX}
      chamferY={chamferY}
    >
      <div
        data-slot="cyber-image-viewport"
        className="relative h-full w-full overflow-hidden"
        style={{
          clipPath: cyberFrameClip(chamferX, chamferY),
        }}
      >
        <img
          ref={imgRef}
          data-slot="cyber-image-img"
          src={src}
          alt={alt}
          width={width}
          height={height}
          loading={loading}
          decoding={decoding}
          fetchPriority={fetchPriority}
          srcSet={srcSet}
          sizes={sizes}
          draggable={false}
          className={cn('absolute inset-0 z-10 h-full w-full object-cover', imgClassName)}
        />
      </div>
    </CyberFrame>
  )
}
