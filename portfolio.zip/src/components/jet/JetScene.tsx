import { useGSAP } from '@gsap/react'
import { Environment, Lightformer, PerspectiveCamera } from '@react-three/drei'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { gsap } from 'gsap'
import { Suspense, useEffect, useRef, useState, type RefObject } from 'react'
import { DirectionalLight, Group, MathUtils, type PerspectiveCamera as PerspectiveCameraType } from 'three'

import { Jet } from './Jet'

import type { SectionId } from '@/config/sections'
import { getScroller } from '@/lib/smoothScroll'
import { FRAME_GAP, getUiScale, REF_H } from '@/lib/ui-scale'
import { isWebGLAvailable } from '@/lib/webgl'

type Pose = {
  position: [number, number, number]
  rotation: [number, number, number]
}

type SectionPoses = {
  /** Where the jet flies in from as this section becomes active. */
  enter: Pose
  /** The section's authoritative resting pose while it's being read. */
  stay: Pose
  /** Where it heads as the section is about to end. */
  leave: Pose
}

/*
 * All per-section jet behaviour lives here. Want a different entrance,
 * resting spot, or exit? Edit these numbers — nothing else changes.
 *
 * Hero has no scroll-driven entrance (enter === stay): its arrival is
 * the one-off intro flight below instead.
 */
const SECTION_POSES: Record<SectionId, SectionPoses> = {
  hero: {
    enter: { position: [0.5, 0.6, -10.5], rotation: [0.8, 0.8, 0] },
    stay: { position: [0.5, 0.6, -10.5], rotation: [0.8, 0.8, 0] },
    leave: { position: [50, 60, -10.5], rotation: [0, 0.8, 4] },
  },
  about: {
    enter: { position: [-7.5, 80, -5], rotation: [0, -1, 5] },
    stay: { position: [-7.5, 1.3, -5], rotation: [0, -1, 5] },
    leave: { position: [-7.5, -40, -5], rotation: [0, -1, 5] },
  },
  experience: {
    enter: { position: [-20, -20, -10.5], rotation: [0.8, 0.8, 0] },
    stay: { position: [0.5, 0.6, -10.5], rotation: [0.5, 0, 0.1] },
    leave: { position: [30, 6, -25.5], rotation: [0.8, 0.4, 0] },
  },
  // projects: {
  //   enter: { position: [20, 4, -16], rotation: [0.7, 3.8, 0] },
  //   stay: { position: [4, 0.5, -4], rotation: [0.7, 3.8, 0] },
  //   leave: { position: [-30, 5, -20], rotation: [-0.7, 4, -0.3] },
  // },
  projects: {
    enter: { position: [30, 6, -25.5], rotation: [0.8, 0.4, 0] },
    stay: { position: [30, 6, -25.5], rotation: [0.8, 0.4, 0] },
    leave: { position: [0, 150, -14], rotation: [1.2, 4.724, 0] },
  },
  tools: {
    enter: { position: [0, 150, -14], rotation: [1.2, 4.724, 0] },
    stay: { position: [0, 2.2, -14], rotation: [1.2, 4.724, 0] },
    leave: { position: [0, -100, -14], rotation: [1.2, 4.724, 0] },
  },
  contact: {
    enter: { position: [0, -100, -14], rotation: [1.2, 4.724, 0] },
    stay: { position: [-100, -50, -14], rotation: [1.2, 4.724, 0] },
    leave: { position: [-20, 1.5, -8], rotation: [1.5, 6.3, -0.1] },
  },
  // contact: {
  //   enter: { position: [100, 20, -6], rotation: [0.3, 3.7, 0] },
  //   stay: { position: [4, -0.5, -6], rotation: [0.3, 3.7, 0] },
  //   leave: { position: [4, -0.5, -6], rotation: [0.3, 3.7, 0] },
  // },
  footer: {
    enter: { position: [-100, 1.5, -8], rotation: [1.5, 6.3, -0.1] },
    stay: { position: [1, 1.5, -7], rotation: [1.5, 6.3, -0.1] },
    leave: { position: [-16, -3.5, -6], rotation: [0.3, 3.7, 0] },
  },
}

const BASE_FOV = 38
/** Canvas height (= <main> height) at the reference window size, where the scale is 1. */
const REF_CANVAS_H = REF_H - FRAME_GAP * 2

/**
 * Keeps the jet the same size relative to the page text. The rest of the page
 * scales by `ui-scale`, so the camera's vertical field of view is widened/narrowed
 * to make the jet's on-screen size follow that same scale instead of the raw
 * canvas height. At the reference size this is exactly BASE_FOV.
 */
function ScaledCamera() {
  const camera = useThree((s) => s.camera)
  const height = useThree((s) => s.size.height)

  useFrame(() => {
    if (!('fov' in camera)) return
    const persp = camera as PerspectiveCameraType
    const tanBase = Math.tan(MathUtils.degToRad(BASE_FOV / 2))
    const fov = MathUtils.radToDeg(2 * Math.atan((tanBase * height) / (getUiScale() * REF_CANVAS_H)))
    if (Math.abs(persp.fov - fov) > 0.001) {
      persp.fov = fov
      persp.updateProjectionMatrix()
    }
  })

  return null
}

/** Hero's one-off, time-based arrival — far off-screen start point. */
const INTRO_START: Pose = { position: [-30, -30, 0], rotation: [0.5, 0, -1.5] }

/** Below this progress we're entering; above this, we're leaving. */
const ENTER_END = 0.3
const LEAVE_START = 0.7

/**
 * How tightly the jet tracks the scroll-derived target each frame.
 * 0 = glued 1:1 to scroll, identical feel to the old `scrub: true`
 * timeline (zero lag). Raise a little (8–14) only to file off jitter
 * from a rough scroll input — much past that and it starts to feel
 * like the jet is chasing the page instead of riding it.
 */
const SMOOTHING = 6

function smoothstep(t: number) {
  const c = Math.min(Math.max(t, 0), 1)
  return c * c * (3 - 2 * c)
}

function blend(a: Pose, b: Pose, t: number): Pose {
  const lerp3 = (from: Pose['position'], to: Pose['position']) =>
    from.map((v, i) => MathUtils.lerp(v, to[i], t)) as Pose['position']

  return { position: lerp3(a.position, b.position), rotation: lerp3(a.rotation, b.rotation) }
}

/** Pose the jet should be chasing right now, purely as a function of progress. */
function targetPose(section: SectionId, progress: number): Pose {
  const { enter, stay, leave } = SECTION_POSES[section]

  if (progress <= ENTER_END) return blend(enter, stay, smoothstep(progress / ENTER_END))
  if (progress >= LEAVE_START)
    return blend(stay, leave, smoothstep((progress - LEAVE_START) / (1 - LEAVE_START)))

  return stay
}

function JetController({
  active,
  progressRef,
}: {
  active: SectionId
  progressRef: RefObject<Record<SectionId, number>>
}) {
  const jetRef = useRef<Group | null>(null)
  const footerKeyRef = useRef<DirectionalLight | null>(null)
  const footerRimRef = useRef<DirectionalLight | null>(null)
  const introRef = useRef<gsap.core.Timeline | null>(null)
  const introDone = useRef(false)

  useGSAP(() => {
    const jet = jetRef.current
    if (!jet) return

    const heroStay = SECTION_POSES.hero.stay

    introRef.current = gsap
      .timeline({
        delay: 3,
        onComplete: () => {
          introDone.current = true
        },
      })
      .to(jet.position, {
        x: heroStay.position[0],
        y: heroStay.position[1],
        z: heroStay.position[2],
        duration: 2,
        ease: 'power2.out',
      })
      .to(
        jet.rotation,
        {
          x: heroStay.rotation[0],
          y: heroStay.rotation[1],
          z: heroStay.rotation[2],
          duration: 2,
          ease: 'power2.out',
        },
        '<'
      )

    return () => {
      introRef.current?.kill()
    }
  }, [])

  useEffect(() => {
    const on = active === 'footer'
    const key = footerKeyRef.current
    const rim = footerRimRef.current

    if (key) {
      gsap.to(key, {
        intensity: on ? 2.3 : 0,
        duration: 0.8,
        ease: 'power2.out',
        overwrite: 'auto',
      })
    }

    if (rim) {
      gsap.to(rim, {
        intensity: on ? 1.5 : 0,
        duration: 0.8,
        ease: 'power2.out',
        overwrite: 'auto',
      })
    }
  }, [active])

  /*
   * If the user scrolls before the intro finishes, stop racing it
   * against the real, scroll-driven pose and hand control to the
   * frame loop immediately — from wherever the jet currently sits.
   */
  useEffect(() => {
    const skipIntro = () => {
      if (introDone.current) return
      introRef.current?.kill()
      introDone.current = true
    }

    const scroller = getScroller() ?? window
    scroller.addEventListener('scroll', skipIntro, { passive: true, once: true })
    return () => scroller.removeEventListener('scroll', skipIntro)
  }, [])

  useFrame((_, delta) => {
    const jet = jetRef.current
    if (!jet || !introDone.current) return

    // progressRef now stores 0–100 per the tracker's contract; targetPose's
    // ENTER_END/LEAVE_START math is written for a 0–1 fraction, so normalize here.
    const progress = (progressRef.current?.[active] ?? 0) / 100
    const target = targetPose(active, progress)

    if (SMOOTHING <= 0) {
      jet.position.set(...target.position)
      jet.rotation.set(...target.rotation)
      return
    }

    jet.position.x = MathUtils.damp(jet.position.x, target.position[0], SMOOTHING, delta)
    jet.position.y = MathUtils.damp(jet.position.y, target.position[1], SMOOTHING, delta)
    jet.position.z = MathUtils.damp(jet.position.z, target.position[2], SMOOTHING, delta)

    jet.rotation.x = MathUtils.damp(jet.rotation.x, target.rotation[0], SMOOTHING, delta)
    jet.rotation.y = MathUtils.damp(jet.rotation.y, target.rotation[1], SMOOTHING, delta)
    jet.rotation.z = MathUtils.damp(jet.rotation.z, target.rotation[2], SMOOTHING, delta)
  })

  return (
    <>
      <directionalLight ref={footerKeyRef} position={[-6, 5, 7]} intensity={0} color="#cdd6e4" />
      <directionalLight ref={footerRimRef} position={[6, -3, 5]} intensity={0} color="#ff3a2d" />
      <group ref={jetRef} position={INTRO_START.position} rotation={INTRO_START.rotation}>
        <Suspense fallback={null}>
          <Jet footer={active === 'footer'} />
        </Suspense>
      </group>
    </>
  )
}

export function JetScene({
  active,
  progressRef,
}: {
  active: SectionId
  progressRef: RefObject<Record<SectionId, number>>
}) {
  const [visible, setVisible] = useState(() => typeof document === 'undefined' || !document.hidden)
  const [glOK] = useState(isWebGLAvailable)

  useEffect(() => {
    const onVisibility = () => setVisible(!document.hidden)
    document.addEventListener('visibilitychange', onVisibility)
    return () => document.removeEventListener('visibilitychange', onVisibility)
  }, [])

  if (!glOK) return null

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-50">
      <Canvas
        // Always render at least 1.5x (supersampled on 1x screens) and up to 2x for crisp edges.
        dpr={[1.5, 2]}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
        frameloop={visible ? 'always' : 'never'}
      >
        <PerspectiveCamera makeDefault fov={BASE_FOV} position={[0, 1.2, 6]} />
        <ScaledCamera />
        <directionalLight position={[0, 0.8, 7]} intensity={4.8} />
        <hemisphereLight args={['#ffffff', '#8B0606', 0.7]} />
        <ambientLight intensity={0.25} />
        {active === 'footer' && (
          <Environment resolution={256} frames={1} background={false}>
            <Lightformer form="circle" intensity={6} position={[3, 1.5, 6]} scale={[1.4, 1.4, 1]} />
            <Lightformer form="rect" intensity={3.8} position={[0, 7, 5]} scale={[9, 3, 1]} />
            <Lightformer
              form="rect"
              intensity={2.1}
              color="#ffffff"
              position={[-7, -2, 6]}
              scale={[5, 2, 1]}
            />
            <Lightformer
              form="ring"
              intensity={1.6}
              color="#c6d2e0"
              position={[6, 3, -6]}
              scale={[4, 4, 1]}
            />
            <Lightformer
              form="rect"
              intensity={1.15}
              color="#e23a2c"
              position={[7, -1, 2]}
              scale={[2.5, 5, 1]}
            />
          </Environment>
        )}
        <JetController active={active} progressRef={progressRef} />
      </Canvas>
    </div>
  )
}
